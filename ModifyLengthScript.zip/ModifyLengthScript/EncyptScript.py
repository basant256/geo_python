#import arcpy
import Config as config
import arcpy
import cx_Oracle
import os
import sys
import time
import pandas as pd
import logging
from datetime import datetime
from datetime import date

start_time = time.time()
formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')

FolderPath = r"E:\2021_Enhancements\KT_Deployment\Production_Solution_GIS Portal_190523\Stging_Scripts\Aug07ADVCTRL\EncryptScript"
#SdePath = FolderPath + "\sde_connection\GISTST_NE.sde"
#logging.basicConfig(filename='Encription'+datetime.now().strftime('%Y-%m-%d')+'.log', level=logging.INFO,format='%(asctime)s - %(message)s',datefmt='%Y-%m-%d %H:%M:%S')
globalFlag = True
def getCurrentFilePath():
    curDir = os.path.dirname(sys.argv[0])
    return os.path.abspath(curDir)

#get file directory name
mydir = getCurrentFilePath()
CurrentTime = datetime.now().strftime("%Y%m%d-%H%M%S")
logDareTime = "_"+CurrentTime
logFilePath= mydir +"\\" +"Log"
arcpy.env.workspace = logFilePath
if not os.path.isdir(logFilePath):
     os.mkdir(logFilePath)
logCFullName =  logFilePath +"\\" +"Encription"+ logDareTime +".log"
LogFileName = "Encription"+ logDareTime

def setup_logger(name, log_file, level=logging.INFO):
    """To setup as many loggers as you want"""
    handler = logging.FileHandler(log_file)        
    handler.setFormatter(formatter)
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)
    return logger

Logger = setup_logger(LogFileName,logCFullName)

Logger.info('Process Started')
Logger.info("LogPath {0}".format(logFilePath))

def write_log1(msg):
    try:
        print( date.today().strftime("%d/%m/%Y") + " | " +datetime.now().time().strftime('%H:%M:%S')  + " | " + msg )
        Logger.info(msg)
        sys.stdout.flush()
    except Exception as e:
        Logger.exception(e)
        print( date.today().strftime("%d/%m/%Y") + " | " +datetime.now().time().strftime('%H:%M:%S')  + " | " + str(e) )
        sys.stdout.flush()
        sys.exit()
        globalFlag = False

def start_encryption():
    globalFlag=True
    try:
        #to run python script in arccatalog python window
        #`execfile('D:/basant/EncyptScript.py')`
        
        connection = cx_Oracle.connect(config.username,config.password,config.dsn,encoding=config.utf)
        print('Connected')
        
        executeProc = False
    except Exception as err:
        print('Connection Error:',err)
        write_log1("Error in database connection {0}".format(err))
        globalFlag = False
    else:

        try:
            
            procedure = "ENCRYPT_USER_TAB_COL"
            
            df = pd.read_excel(FolderPath + '/AD_Test_E.xlsx',usecols=[0,1])

            df = df.where(pd.notnull(df), None)

            df['Column Name'] = df.groupby(['Table  Name'])['Column Name'].transform(lambda x : ','.join(x))
            # drop duplicate data
            df = df.drop_duplicates()
            print(df)

            for index, row in df.iterrows():
                cur = connection.cursor()
                ref_cursor = connection.cursor()
                
                tabe_name = row['Table  Name'].split(".")[1]
                
                
                try:
                    cur.callproc(procedure, [tabe_name,row['Column Name'],'sTcAC#VKE@12345sTcAC#VKE@12345AA',ref_cursor])
                    #print(ref_cursor)
                    for data_row in ref_cursor:
                        # Write data lines
                        colName=row['Column Name']
                        #logging.log(logging.INFO, format'{0} {1}',tabe_name,colName)#format='%(asctime)s - %(message)s'
                        
                        write_log1(tabe_name+' '+colName)
                        print(data_row)
                        cur.close()
                except Exception as err:
                    print("Error in table and column: ",err)
                    write_log1("Error in table and column".format(err))
                    globalFlag = False
                #executeProc=myconn.execute("CALL ENCRYPT_USER_TAB_COL('NC_USER','NOTE','sTcAC#VKE@12345sTcAC#VKE@12345AA')")
                    
                
        except Exception as err:
             print("Reading File Error:",err)
             write_log1("Reading File Error: {0}".format(err))
             globalFlag = False
    finally:
        try:
            if cur:
                cur.close()
        except Exception as err:
            write_log1("Error in database connection {0}".format(err))
        if connection:
             connection.commit()
             connection.close()
        
        print("Script Executed Successfully")
        write_log1("Script Executed Successfully")
        return globalFlag
    