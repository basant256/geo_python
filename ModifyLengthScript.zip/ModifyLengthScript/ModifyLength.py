import Config as config
import arcpy
import os
import sys
import time
import logging
import pandas as pd
from datetime import datetime
from datetime import date

start_time = time.time()
formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
def getCurrentFilePath():
    curDir = os.path.dirname(sys.argv[0])
    return os.path.abspath(curDir)

#get file directory name
mydir = getCurrentFilePath()

SdePath = mydir + config.sdeconnPath
globalFlag = True

CurrentTime = datetime.now().strftime("%Y%m%d-%H%M%S")
logDareTime = "_"+CurrentTime
logFilePath= mydir +"\\" +"Log"
arcpy.env.workspace = logFilePath
if not os.path.isdir(logFilePath):
     os.mkdir(logFilePath)
logCFullName =  logFilePath +"\\" +"AdvanceControl"+ logDareTime +".log"
LogFileName = "AdvanceControl"+ logDareTime

def setup_logger(name, log_file, level=logging.INFO):
    """To setup as many loggers as you want"""
    handler = logging.FileHandler(log_file)        
    handler.setFormatter(formatter)
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)
    return logger

Logger = setup_logger(LogFileName,logCFullName)

Logger.info('Process Started')
Logger.info("LogPath {0}".format(logFilePath))

def write_log(msg):
    try:
        print( date.today().strftime("%d/%m/%Y") + " | " +datetime.now().time().strftime('%H:%M:%S')  + " | " + msg )
        Logger.info(msg)
        sys.stdout.flush()
    except Exception as e:
        Logger.exception(e)
        print( date.today().strftime("%d/%m/%Y") + " | " +datetime.now().time().strftime('%H:%M:%S')  + " | " + str(e) )
        sys.stdout.flush()
        sys.exit()
        globalFlag = False
def modify_length():
    globalFlag=True
    try:
        #E:\2021_Enhancements\KT_Deployment\Production_Solution_GIS Portal_190523\Stging_Scripts\Aug07ADVCTRL\ModifyLengthScript\sde_connection\GISTST_NE.sde\NE.TELCO\NE.SPAN_TEST
        #`execfile('D:/basant/ModifyLength.py')`
        #logging.basicConfig(filename='AdvanceControl'+datetime.now().strftime('%Y-%m-%d')+'.log', level=logging.INFO,format='%(asctime)s - %(message)s',datefmt='%Y-%m-%d %H:%M:%S')
        #print("connected :" +SdePath)
        myconn= arcpy.ArcSDESQLExecute(SdePath )
        #print("connected :" +SdePath)
        
    except Exception as err:
        in_table = SdePath 
        #in_table = SdePath +'/NE.TELCO'
        write_log("Error in sde connection {0}".format(err))
        print("Database connection error: ",err)
        globalFlag = False
    else:
        
        #logging.warning('Start Time='+row['Table  Name'])
        df = pd.read_excel(mydir + '/AD_Test_M.xlsx',usecols=[0,1])
        #df = pd.read_excel(mydir + '/AD_Test_M1.xlsx',usecols=[0,1])

        df = df.where(pd.notnull(df), None)

        df['Column Name'] = df.groupby(['Table  Name'])['Column Name'].transform(lambda x : ','.join(x))
        # drop duplicate data
        df = df.drop_duplicates()
        print(df)
        write_log("Length Modifying script Started.... ")
        for index, row in df.iterrows():
            tabe_name = row['Table  Name'].split(".")[1]
            tabe_name = row['Table  Name']
            in_field = row['Column Name']
            columnsArr = in_field.split(",")
            print(tabe_name,"==",columnsArr)
            for column in columnsArr:
                inFeatures=SdePath +"\\"+ row['Table  Name']
               # inFeatures=SdePath +"\\NE.TELCO\\"+ row['Table  Name']
                print("inFeatures :"+inFeatures) 
                fieldName1=column+"_R"
                new_field_name=column
                new_field_alias = column
                fieldAlias=column+"_R"
                field_type="Text"
                fieldlength="255"
                field_is_nullable="NULLABLE"
                clear_field_alias="false"

                try:
                    #add new field in spatial table
                    arcpy.management.AddField(inFeatures, fieldName1, "TEXT",field_length=fieldlength,
                              field_alias=fieldAlias, field_is_nullable="NULLABLE")
                except Exception as err:
                    print("Add Field Error: ",err)
                    #logging.warning("Add Field Error:  {0}".format(err))
                    write_log("Add Field Error:  {0}".format(err))
                    globalFlag = False
                else:
                    print("New Field Added.")
                    write_log("New Field Added.")
                    #logging.warning('Table Name='+row['Table  Name']+' '+'FieldName='+fieldName1+' '+'Field Length'+fieldlength)
                    write_log('Table Name='+row['Table  Name']+' '+'FieldName='+fieldName1+' '+'Field Length'+fieldlength)
                    try:
                        
                        #calculate values from old field to new field
                        calField = "UPDATE {0} set {1} = {2}".format(row['Table  Name'].split('\\')[1],fieldName1,column)
                        #arcpy.management.CalculateField(inFeatures, fieldName1,"!"+column+"!",'PYTHON')
                        print(calField)
                        myconn.startTransaction()
                        
                        Result1 = myconn.execute(calField)
                        
                        myconn.commitTransaction()
                        #AdvContArcSDE  = arcpy.ArcSDESQLExecute(SdePath)
                        
                    except Exception as err:
                        print("Calculate Error: table{0}, column{1} and {2}".format(inFeatures,column,err))
                        #logging.warning("Calculate Error: table{0}, column{1} and {2}".format(inFeatures,column,err))
                        write_log("Calculate Error: table{0}, column{1} and {2}: ".format(inFeatures,column,err))
                        globalFlag = False
                    else:
                        print("Calculation happened in new field wrt old field.")
                        #logging.warning('Calculated values from old field to new field')
                        write_log("Calculated values from old field to new field")
                        try:
                            #Delete old field after getting calculated
                            fieldNameList = [column]
                            arcpy.DeleteField_management(inFeatures, fieldNameList)
                        except Exception as err:
                            print("Field Delete Error: ", err)
                            #logging.warning("Field Delete Error:  {0}".format(err))
                            write_log("Field Delete Error:  {0}".format(err))
                            globalFlag = False
                            
                        else:
                            print("Old Field Deleted")
                            write_log("Old Field Deleted")
                            try:
                                #Change/ alter the new field name as old field name
                                field_length=255
                                arcpy.management.AlterField(inFeatures, fieldName1,new_field_name,new_field_alias,
                                        field_type,field_length,field_is_nullable,clear_field_alias)
                            except Exception as err:
                                print("Alter Failed Error: table{0}, column{1} and {2}".format(inFeatures,column,err))
                                #logging.warning("Alter Failed Error: table{0}, column{1} and {2}".format(inFeatures,column,err))
                                write_log("Alter Failed Error: table{0}, column{1} and {2}".format(inFeatures,column,err))
                                globalFlag = False
                            else:
                                print("New Field Renamed as Old Field")
                                #logging.warning("New Field Renamed as Old Field")
                                write_log("New Field Renamed as Old Field")
                                
                            
        
    finally:
        print("Script Executed Successfully.")
        write_log("Script Executed Successfully.")
        write_log("Length Modifying script Ended.... ")
        return globalFlag
