import arcpy
import os
import sys
import pandas as pd
import numpy as np
from datetime import datetime
from datetime import date
from decimal import Decimal
from string import ascii_letters


from EncyptScript import *
from ModifyLength import *


def Start_encrypting_data():
    try:
        executionFlag=modify_length()
        #print(executionFlag)
        #executionFlag=True
        if executionFlag==True:
            #executionFlag=start_encryption()
            print(executionFlag)
    except Exception as e:
        print(e)

def main():       
    Start_encrypting_data()

if __name__=='__main__':
    main()