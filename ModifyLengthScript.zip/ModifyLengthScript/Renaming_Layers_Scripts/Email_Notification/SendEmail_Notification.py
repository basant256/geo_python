import arcpy
import json
import os, sys
import inspect
import re
import os.path
from os import path
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.MIMEBase import MIMEBase
from email import Encoders
import io
from string import Template
from datetime import datetime


#------------------------------------Vaiable Declaration--------------------------------
listAttachments =[]
blErrorFound = False
strLine = "-----------------------------------------------------------------------------------------------------------------------------------"
strStars ="***********************************************************************************************************************************"
#--------------------------------------getCurrentFilePath--------------------------------

#getCurrent file path directory
def getCurrentFilePath():
    curDir = os.path.dirname(sys.argv[0])
    return os.path.abspath(curDir)

#-------------------------------------DisplayInfo-----------------------------------------------------   
def DisplayInfo(msg):
    try:
        print (msg)             

    except Exception as e:
        DisplayInfo(str(e))

#get file directory name
mydir = getCurrentFilePath()
EmailTemplate = mydir + "/Email_template.txt"
#------------------------------------------------------------------------------------------
#******************************************************************************************
#----------------------------------Read Config JSON files ---------------------------------
configFilepath = mydir + "/Configuration/EmailInfo.JSON"
EmailTemplate = mydir + "/Configuration/Email_template.txt"


#Check for config file path existance
def checkfilepath(filepath,FileType):
    try:
        if os.path.isfile(filepath):     
            DisplayInfo("Configuration file  exists : " + filepath)
            DisplayInfo(strLine)
            
        else:            
            msg = "Error : {} file does not exists in path: {} ".format(FileType,filepath)
            DisplayInfo(msg)               
            sys.exit()
        
    except Exception as e:
        DisplayInfo("Exception in function - "+ inspect.stack()[0][3] +" : " + str(e))
        sys.exit()

#Check for the config file exits or not
checkfilepath(configFilepath,"Configuration")

#Check for the email template exits or not
checkfilepath(EmailTemplate,"Email_Template")

#Read configuration file
with open(configFilepath) as json_file:
    configFileData = json.load(json_file)

EmailInfo = configFileData["EMAIL_INFO"]

#--------------------------------------------ValidateFolderPathExists--------------------------------------------
def ValidateFolderPathExists(Folderpath):
    try:
        global blErrorFound
        if not os.path.isdir(Folderpath):
            msg = "Error : Source Folder path not found: " + Folderpath;
            DisplayInfo(msg)
            blErrorFound =True
            return True
        else:
            return False  

    except Exception as e:
        FilePathsExits =False
        dlLog.exception(e)
        print (str(e))
        return True

#--------------------------------------------ValidateEmailParameters--------------------------------------------
def ValidateEmailParameters():
    try:
        global blErrorFound

        for key, value in EmailInfo.items():
            if len(value) == 0:
                DisplayInfo("Value should not be empty  for Parameter '{}' in Configuration file: {}".format(key,configFilepath ))
                blErrorFound = True  

    except Exception as e:
        blErrorFound =True
        DisplayInfo(e)
        
FromMailID= EmailInfo["FromMailId"]
password = EmailInfo["Password"]		
ToMailID = EmailInfo["ToMailId"]
hostName  = EmailInfo["Host"]
portNumber = str(EmailInfo["Port"])
subject = EmailInfo["EmailSubject"]
bodyMessage = EmailInfo["Message"]
logDirectoryPath = EmailInfo["log_Folder"]
logFileExtension = EmailInfo["logFile_Extension"]
logFileName = EmailInfo["logFileNamePattern"]

ValidateEmailParameters()
ValidateFolderPathExists(logDirectoryPath)

if blErrorFound:
    DisplayInfo("Please fix the  above Configurations error found")
    sys.exit()
        
#--------------------------------------------AddAttachmentToEmail--------------------------------------
def AddAttachmentToEmail(filePath):
    attachementPart = None
    try:       
         
        if len(filePath) > 0:            
            attachementPart = MIMEBase('application', "octet-stream")
            attachementPart.set_payload(open(filePath, "rb").read())
            Encoders.encode_base64(attachementPart)           
            attachementPart.add_header('Content-Disposition', 'attachment; filename='+ os.path.basename(filePath))                 

        else:
            msg = "Error : File does not exists in path:{0}".format(filepath)
            DisplayInfo(msg)            
            #sys.exit()
        return attachementPart
        
    except Exception as e:
        DisplayInfo("Exception in function - "+ inspect.stack()[0][3] +" : " + str(e))
        
#-------------------------------------send_email-----------------------------------------------------
def send_email(subject,message_body,listAttachments):
    s_status = False
    message = MIMEMultipart()
    try:   
        
        if len(hostName) == 0 or len(portNumber) == 0 or len(FromMailID) == 0 or len(password) == 0 or len(ToMailID) == 0:            
            DisplayInfo("Error: Email Parameter values from should not be empty")
            return s_status           
               
        #Check for Host name and port numbers are valid
        try:
            email_smtp = smtplib.SMTP(hostName, port= portNumber)
        except Exception as e:
            DisplayInfo("Error: Issue with hostname or port number for sending Email :{}".format(str(e)))
            return s_status

        email_smtp.starttls()
        email_smtp.ehlo

        #Check for email login credentials
        try:
            email_smtp.login(FromMailID,password)
        except Exception as e:
            print "Started Sending Mail"
        
        message['Subject'] = subject
        message['From'] = FromMailID        
        message['To'] = ", ".join(ToMailID)        

        #Attach Summary log file
        for fileAttachment in listAttachments:
            if os.path.isfile(fileAttachment):
                if len(fileAttachment) > 0:
                    logAttachment = AddAttachmentToEmail(fileAttachment)
                    if logAttachment is not None:
                        message.attach(logAttachment)
                        DisplayInfo("Attached log file:{0}".format(fileAttachment))             
            
        message.attach(MIMEText(message_body, 'plain'))
        #Send email 
        email_smtp.sendmail(FromMailID, ToMailID,message.as_string())        
        email_smtp.quit()
        s_status = True        
        
        
    except Exception as e:         
        DisplayInfo( "Exception in function - Issue while sending email "+ inspect.stack()[0][3] +" : " + str(e))
        s_status = False
        return s_status
    finally:        
        del message
        return s_status
        sys.exit()

#--------------------------------------------read_mail_template------------------------------------
def read_mail_template(file_path):
    with io.open(file_path, 'r', encoding='utf-8') as template_file:
        template_file_content = template_file.read()
    return Template(template_file_content)

#--------------------------------------------SendEmailNotification--------------------------------------
def SendEmailNotification(subject, bodyMessage,list_attchments):
    try:
        message_template = read_mail_template(EmailTemplate)
        print EmailTemplate
        messageInfo = message_template.substitute(MESSAGE_BODY = bodyMessage)
        
        blvalue= send_email(subject, messageInfo,list_attchments)
        if not blvalue:
            DisplayInfo("Mail notification failed")
        else:
            DisplayInfo("Sent email Successfully")

        DisplayInfo(strStars)
     
    except Exception as e:        
        msg = "Exception in function - "+ inspect.stack()[0][3] +" : " + str(e)
        DisplayInfo(msg)
        sys.exit()

#--------------------------------------------GetLatestFileFromDirectory-------------------------------
def GetLatestFileFromDirectory(path):
    try:        
        files = [os.path.join(path, x) for x in os.listdir(path) if x.endswith("."+logFileExtension) and logFileName in x]        
                
        if len(files) > 0:
            paths = [os.path.join(path, basename) for basename in files]
            return max(paths, key=os.path.getmtime)
        else:        
            DisplayInfo("No required files found in the folder : {0}, with Extension : '{1}' and  File Name Contains :'{2}'".format(path,logFileExtension, logFileName))
            sys.exit()
    except Exception as e:        
        msg = "Exception in function - "+ inspect.stack()[0][3] +" : " + str(e)
        DisplayInfo(msg)

#--------------------------------------------StartMainFunction----------------------------------------
def StartMainFunction():
    try:
        DisplayInfo("Process Started")
        #Check for Email Template
        if path.exists(EmailTemplate):
            print logDirectoryPath
            #Check for Log folder path 
            if os.path.isdir(logDirectoryPath):
                #Check for the latest log file the log folder Path
                filename =GetLatestFileFromDirectory(logDirectoryPath)
                
                if os.path.isfile(filename):
                    #if path.exists(filename):
                    print ("Log file name : {}".format(filename))
                    
                    #Add Log file to list attchments
                    listAttachments.append(filename)

                    #Start send email module
                    SendEmailNotification(subject, bodyMessage,listAttachments)
                else:
                     DisplayInfo("Error : No files found in the directory {} , With file extension .{}".format(logDirectoryPath,logFileExtension))                
            else:
                DisplayInfo("Error : No Log folder directory found: {}".format(logDirectoryPath))
        else:
            DisplayInfo("Error : No Email Template found : {}".format(EmailTemplate))
      
        DisplayInfo("Process completed")
     
    except Exception as e:        
        msg = "Exception in function - "+ inspect.stack()[0][3] +" : " + str(e)
        DisplayInfo(msg)

#--------------------------------------------Start Main function------------------------------------------
StartMainFunction()
















