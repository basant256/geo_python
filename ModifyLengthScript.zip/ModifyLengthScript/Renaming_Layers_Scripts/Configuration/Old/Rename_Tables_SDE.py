import arcpy as env
import logging
import json
import os, sys
import inspect


CurrentTime  = time.strftime("%Y%m%d-%H%M%S")
logfileName = "Common_Rename_Tables_SDE_"+CurrentTime+".log"
strLine = "---------------------------------------------------------------------------------------------"
strStars ="**********************************************************************************************"

#-------------------------------logfile creation--------------------------------------

#getCurrent file path directory
def getCurrentFilePath():
    curDir = os.path.dirname(sys.argv[0])
    return os.path.abspath(curDir)

#get file directory name
mydir = getCurrentFilePath()

print ("Executing from Current folder: " + mydir)

logFilePath= mydir +"/" +"NA_DB_Log"
arcpy.env.workspace = logFilePath

print ("Log file path :" + logFilePath)
#logging.info('Log file path' +  logFilePath)

if not os.path.isdir(logFilePath):
     os.mkdir(logFilePath)

logging.basicConfig(filename = logFilePath +"/"+ logfileName,  format='%(asctime)s %(message)s',level=logging.INFO,filemode='w')

logging.info('Started')
logging.info("workspace {0}".format(logFilePath))

#******************************************************************************************
#----------------------------------Read Config JSON files ---------------------------------
configFilepath = mydir + "/Configuration/GENERAL_RENAME.JSON"

#Check for config file path existance
def checkfilepath(filepath):
    try:
        if os.path.isfile(filepath):
            print ("Configuration file  exists : " + filepath)
            logging.info("Configuration file  exists : " + filepath)
            logging.info("-------------------------------------------------------")
            
        else:           
            print ("Configuration file does not exists in path: " + filepath)
            logging.info("Configuration File doest not exists in path: " + filepath)   
            sys.exit()
        
    except Exception as e:
        logging.exception("Exception in function - "+ inspect.stack()[0][3] +" : " + str(e))
        sys.exit()

#Check for the config file exits or not
checkfilepath(configFilepath)

#Read configuration file
with open(configFilepath) as json_file:
    configFileData = json.load(json_file)

logging.info('Completed reading Configuration file data')
print ('Completed reading Configuration file data')
#******************************************************************************************

#Common_SDE_Path
Common_SDE_Path_data = configFileData["FEATURECLASS_SDE_PATH"]
fc_sde_path = Common_SDE_Path_data["COMMON_SDE_PATH"]


#ALl feature classes
All_FeatureClasses = configFileData["COMMON_FEATURE_CLASSES"]

#Admin Data from
Common_Admin_Path = configFileData["ADMIN_CONNECTION_PATH"]
fc_admin_path = Common_Admin_Path["COMMON_ADMIN_CON"]

print ("Completed reading Configfile data")

#*****************************************************************************************
#Validate GDB paths

def ValidateIPFeatureClasses(gdbPath):
    try:        
        if not arcpy.Exists(gdbPath):
            msg = "GDB or Sde path not found :{0}".format(gdbPath)
            logging.info(msg)
            print (msg)
            sys.exit()        

    except Exception as e:
        logging.exception(e)
        print (str(e))
        sys.exit()

#Validating paths from config file data
ValidateIPFeatureClasses(fc_sde_path)
ValidateIPFeatureClasses(fc_admin_path)  

#************************************Variables Declatration********************************************************
varOld= "_OLD"

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#Remove schema lock with admin credentials
def SDESchemaUnlock(adminSDEpath):
    try:                
        #Block Connections, Dont accept connections from other users
        arcpy.AcceptConnections(adminSDEpath,False)
        print("Dont accept connections from other users")
        
        #Disconnect all users in the GIS Databases
        arcpy.DisconnectUser(adminSDEpath,"ALL")
        print("Disconnect all users")
        
        #Accept Geo database connections to the CBS database
        arcpy.AcceptConnections(adminSDEpath,True)
        print("Connect Again")

        arcpy.ClearWorkspaceCache_management()
        arcpy.env.workspace = ""

       
    except Exception as e:
        logging.exception("Exception in function - "+ inspect.stack()[0][3] +" : " + str(e))
        sys.exit()


#Renameing tables in sde path
def Rename_Tables_SDE(sdePath, AdminPath):
    try:
                  
        for exitingTable in All_FeatureClasses:
            logging.info(strLine)            
            
            orgTableName= All_FeatureClasses[exitingTable]           
            
            #Existing table path with table name (_New feature class)
            exitingTablePath = os.path.join(sdePath, exitingTable)
            
            #Skip if feature does not exists
            if  not arcpy.Exists(exitingTablePath):
                continue
            if not orgTableName  in exitingTable:
                print ("Mismatch exiting table: {0}, Orignal table {1}".format(exitingTable, orgTableName))
                continue
            
            #Original table name Path (original table)
            renameTablePath =  os.path.join(sdePath, orgTableName)
            #Check whether orginal Name exists in the sde

            #Renaming original table to "_old"
            oldOriginalTable = orgTableName + varOld
            oldOrignalTablePath = os.path.join(sdePath, oldOriginalTable)          
           
            strTableStatus = "Started renaming table : {0} , Dest Path :{1} ".format(exitingTable,exitingTablePath)
            print (strTableStatus)
            logging.info(strTableStatus)
            
            #Check whether already original table exits
            if arcpy.Exists(renameTablePath):
                
                strschema = "Started unlocking schema : " + orgTableName
                print (strschema)
                logging.info(strschema)
                SDESchemaUnlock(AdminPath)
                print ("Unlocked Schema for table : " + orgTableName)
                logging.info("Unlocked Schema: " + orgTableName)

                #After schema unlock delete exiting table                
                arcpy.Rename_management(renameTablePath, oldOrignalTablePath)
                print ("Renamed orignal table : to " + oldOrignalTablePath)
                logging.info("Renamed orignal table to : " + oldOrignalTablePath)

            
            #Rename table name
            arcpy.Rename_management(exitingTablePath, renameTablePath)

            strTableStatus = "Completed renaming table : {0} , Dest path :{1} ".format(exitingTable,renameTablePath)                    
            print (strTableStatus)
            logging.info(strTableStatus)

            #Delete original table which we renamed to old if exits
            if arcpy.Exists(oldOrignalTablePath):
                arcpy.Delete_management(oldOrignalTablePath)
                print ("Deleted original table " + oldOrignalTablePath)
                logging.info("Deleted original table " + oldOrignalTablePath)

        
    except Exception as e:
        logging.exception("Exception in function - "+ inspect.stack()[0][3] +" : " + str(e))
        sys.exit()

fcClassExist = True
def ValidateFeatureclasses():
    try:
        global  fcClassExist
        fcClassExist = True
        Total_FC = All_FeatureClasses
        
        listfc= []
        #Validate feature exits in work
        for inv_FC in Total_FC:
            in_FeatureClass = fc_sde_path+ "//" + inv_FC
            outFC_name = Total_FC[inv_FC]
            #print in_FeatureClass
            if  not arcpy.Exists(in_FeatureClass):
                logging.info("Feature class does not exists  for FC  " + in_FeatureClass)
                listfc.append(in_FeatureClass)
                fcClassExist = False
            
            if not outFC_name in inv_FC:
                logging.info("Feature class mistmatch for  new_FC : {0}, original FC : {1} ".format(inv_FC,outFC_name))
                fcClassExist = False
                
        ''' Commented
        #Exit the  if feature class doest not exists
        if(bool(fcClassExist) == False):
                print ("Some issues found with feature class ,plese check the log file")
                sys.exit()
        '''
    except Exception as e:
        logging.exception("Exception in function - "+ inspect.stack()[0][3] +" : " + str(e))
        sys.exit()
        

#Rename Tables in sde functionality
def Rename_FeatureClasses_Functionality():
    try:
        logging.info(strLine)
        startRename = "Started renaming tables in SDE Path"
        print (startRename)
        logging.info(startRename)
        logging.info(strLine)

        #Validate individual fc
        ValidateFeatureclasses()
        
        #Rename common tables in sde
        Rename_Tables_SDE(fc_sde_path, fc_admin_path)       
       
        logging.info(strStars)
        finishRename = "Completed renaming tables in SDE Path"
        print (finishRename)
        logging.info(finishRename)

        #feature classes not found in sde path, updating to log file
        if(bool(fcClassExist) == False):
                print ("Some issues found with feature class ,plese check the log file")             

    except Exception as e:
        logging.exception("Exception in function - "+ inspect.stack()[0][3] +" : " + str(e))
        sys.exit()

#Start Renaming feature classes from Source to destination
Rename_FeatureClasses_Functionality()



