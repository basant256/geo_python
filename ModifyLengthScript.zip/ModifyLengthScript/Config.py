username = 'ne'
password = 'P0rtal$321'
dsn = 'GISTST'
utf = 'UTF-8'


sdeconnPath="\sde_connection\GISTST_NE.sde"